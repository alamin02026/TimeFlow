package com.timeflow.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class AllocationEngineTest {

    private val demoLimit = 2 * 60 + 52 // 172 minutes

    @Test
    fun sumAlwaysEqualsConfiguredLimit() {
        val result = AllocationEngine.allocate(
            demoLimit,
            mapOf("a" to 5_000_000L, "b" to 3_000_000L, "c" to 1_234_567L, "d" to 1L)
        )
        assertEquals(demoLimit, result.values.sum())
    }

    @Test
    fun exactProportionsWhenDivisible() {
        val result = AllocationEngine.allocate(100, mapOf("a" to 3L, "b" to 1L))
        assertEquals(75, result["a"])
        assertEquals(25, result["b"])
    }

    @Test
    fun equalWeightsSplitEvenly() {
        val result = AllocationEngine.allocate(demoLimit, mapOf("a" to 10L, "b" to 10L))
        assertEquals(86, result["a"])
        assertEquals(86, result["b"])
    }

    @Test
    fun higherWeightNeverGetsLess() {
        val weights = mapOf("heavy" to 9_000L, "mid" to 4_000L, "light" to 500L)
        val r = AllocationEngine.allocate(demoLimit, weights)
        assertTrue(r["heavy"]!! >= r["mid"]!!)
        assertTrue(r["mid"]!! >= r["light"]!!)
        assertEquals(demoLimit, r.values.sum())
    }

    @Test
    fun allZeroWeightsFallBackToEqualSplit() {
        val r = AllocationEngine.allocate(demoLimit, mapOf("a" to 0L, "b" to 0L, "c" to 0L))
        assertEquals(demoLimit, r.values.sum())
        r.values.forEach { assertTrue(it == 57 || it == 58) }
    }

    @Test
    fun zeroWeightAppGetsNothingWhenOthersHaveUsage() {
        val r = AllocationEngine.allocate(demoLimit, mapOf("a" to 1_000L, "b" to 2_000L, "idle" to 0L))
        assertEquals(0, r["idle"])
        assertEquals(demoLimit, r.values.sum())
    }

    @Test
    fun zeroTotalGivesZeros() {
        val r = AllocationEngine.allocate(0, mapOf("a" to 5L, "b" to 7L))
        assertEquals(0, r.values.sum())
    }

    @Test
    fun emptyInputGivesEmptyResult() {
        assertTrue(AllocationEngine.allocate(demoLimit, emptyMap()).isEmpty())
    }

    @Test
    fun singleAppGetsEverything() {
        assertEquals(mapOf("only" to demoLimit), AllocationEngine.allocate(demoLimit, mapOf("only" to 42L)))
    }

    @Test
    fun resultIsDeterministic() {
        val w = mapOf("a" to 1L, "b" to 1L, "c" to 1L)
        assertEquals(AllocationEngine.allocate(100, w), AllocationEngine.allocate(100, w))
    }

    @Test
    fun randomizedSumsAlwaysMatch() {
        val rnd = Random(42)
        repeat(2_000) {
            val total = rnd.nextInt(0, 1_441)
            val n = rnd.nextInt(1, 60)
            val weights = (0 until n).associate { "app$it" to rnd.nextLong(0, 90_000_000L) }
            val r = AllocationEngine.allocate(total, weights)
            assertEquals(total, r.values.sum())
            assertTrue(r.values.all { it >= 0 })
        }
    }

    @Test
    fun hoursAndMinutesSplit() {
        assertEquals(2 to 52, AllocationEngine.hoursAndMinutes(172))
    }
}
