package com.timeflow.app.backup

import androidx.room.withTransaction
import com.timeflow.app.data.db.ActualUsageEntity
import com.timeflow.app.data.db.AppDatabase
import com.timeflow.app.data.db.AppInfoEntity
import com.timeflow.app.data.db.DailySnapshotEntity
import com.timeflow.app.data.db.DemoAllocationEntity
import com.timeflow.app.data.db.DemoProfileEntity
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.time.LocalDate

/** CSV export and JSON backup / restore. Files go only where the user chooses to save them. */
class BackupManager(private val db: AppDatabase) {

    suspend fun exportCsv(out: OutputStream) {
        val names = db.appInfoDao().getAll().associate { it.packageName to it.appName }
        val real = db.actualUsageDao().getAll()
        val demo = db.demoAllocationDao().getAll().associateBy { it.dateEpochDay to it.packageName }
        val keys = (real.map { it.dateEpochDay to it.packageName } + demo.keys).toSortedSet(
            compareBy<Pair<Long, String>>({ it.first }, { it.second })
        )
        val realMap = real.associateBy { it.dateEpochDay to it.packageName }
        out.bufferedWriter().use { w ->
            w.write("date,package,app_name,real_minutes,demo_minutes_(Demo)\n")
            for (k in keys) {
                val realMin = (realMap[k]?.durationMs ?: 0L) / 60_000.0
                val demoMin = demo[k]?.allocatedMinutes
                w.write(
                    "${LocalDate.ofEpochDay(k.first)},${csv(k.second)},${csv(names[k.second] ?: k.second)}," +
                        "${"%.2f".format(java.util.Locale.US, realMin)},${demoMin ?: ""}\n"
                )
            }
        }
    }

    private fun csv(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    suspend fun exportJson(out: OutputStream) {
        val root = JSONObject()
        root.put("format", "timeflow-backup")
        root.put("version", 1)
        root.put("apps", JSONArray().also { a ->
            db.appInfoDao().getAll().forEach {
                a.put(JSONObject().put("p", it.packageName).put("n", it.appName).put("s", it.isSystemApp)
                    .put("f", it.firstSeenAt).put("u", it.updatedAt))
            }
        })
        root.put("usage", JSONArray().also { a ->
            db.actualUsageDao().getAll().forEach {
                a.put(JSONObject().put("p", it.packageName).put("d", it.dateEpochDay)
                    .put("ms", it.durationMs).put("r", it.recordedAt))
            }
        })
        root.put("profiles", JSONArray().also { a ->
            db.demoProfileDao().getAll().forEach {
                a.put(JSONObject().put("id", it.id).put("n", it.name).put("m", it.totalMinutes)
                    .put("x", it.method).put("a", it.isActive).put("c", it.createdAt))
            }
        })
        root.put("allocations", JSONArray().also { a ->
            db.demoAllocationDao().getAll().forEach {
                a.put(JSONObject().put("pr", it.profileId).put("d", it.dateEpochDay).put("p", it.packageName)
                    .put("w", it.weightMs).put("m", it.allocatedMinutes))
            }
        })
        root.put("snapshots", JSONArray().also { a ->
            db.dailySnapshotDao().getAll().forEach {
                a.put(JSONObject().put("d", it.dateEpochDay).put("t", it.totalActualMs)
                    .put("pr", it.demoProfileId ?: JSONObject.NULL).put("m", it.demoTotalMinutes)
                    .put("c", it.createdAt))
            }
        })
        out.bufferedWriter().use { it.write(root.toString()) }
    }

    /** Merges a backup into the database. Returns the number of records read. */
    suspend fun importJson(input: InputStream): Int {
        val root = JSONObject(input.bufferedReader().use { it.readText() })
        require(root.optString("format") == "timeflow-backup") { "Not a TimeFlow backup" }

        val apps = root.getJSONArray("apps").map {
            AppInfoEntity(it.getString("p"), it.getString("n"), it.getBoolean("s"), it.getLong("f"), it.getLong("u"))
        }
        val existingUsage = db.actualUsageDao().getAll().associateBy { it.packageName to it.dateEpochDay }
        val usage = root.getJSONArray("usage").map {
            val key = it.getString("p") to it.getLong("d")
            val old = existingUsage[key]
            ActualUsageEntity(
                id = old?.id ?: 0,
                packageName = key.first,
                dateEpochDay = key.second,
                durationMs = maxOf(it.getLong("ms"), old?.durationMs ?: 0L),
                recordedAt = it.getLong("r")
            )
        }
        val profiles = root.getJSONArray("profiles").map {
            DemoProfileEntity(it.getLong("id"), it.getString("n"), it.getInt("m"), it.getString("x"),
                it.getBoolean("a"), it.getLong("c"))
        }
        val allocations = root.getJSONArray("allocations").map {
            DemoAllocationEntity(0, it.getLong("pr"), it.getLong("d"), it.getString("p"), it.getLong("w"), it.getInt("m"))
        }
        val snapshots = root.getJSONArray("snapshots").map {
            DailySnapshotEntity(it.getLong("d"), it.getLong("t"),
                if (it.isNull("pr")) null else it.getLong("pr"), it.getInt("m"), it.getLong("c"))
        }
        db.withTransaction {
            db.appInfoDao().upsertAll(apps)
            db.actualUsageDao().upsertAll(usage)
            // Keep the currently active profile active; restored ones are history.
            val currentActive = db.demoProfileDao().getActive()
            db.demoProfileDao().insertAllReplace(
                if (currentActive != null) profiles.map { it.copy(isActive = false) } else profiles
            )
            if (currentActive != null) db.demoProfileDao().insertAllReplace(listOf(currentActive))
            // Existing reports for the same day stay; backup only fills missing days.
            val have = db.demoAllocationDao().getAll().map { it.dateEpochDay }.toSet()
            db.demoAllocationDao().insertAll(allocations.filter { it.dateEpochDay !in have })
            val haveSnap = db.dailySnapshotDao().getAll().map { it.dateEpochDay }.toSet()
            snapshots.filter { it.dateEpochDay !in haveSnap }.forEach { db.dailySnapshotDao().upsert(it) }
        }
        return apps.size + usage.size + profiles.size + allocations.size + snapshots.size
    }

    private fun <T> JSONArray.map(f: (JSONObject) -> T): List<T> =
        (0 until length()).map { f(getJSONObject(it)) }
}
