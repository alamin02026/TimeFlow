package com.timeflow.app

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.timeflow.app.data.repo.PreferencesRepository
import com.timeflow.app.ui.AuthHost
import com.timeflow.app.ui.PendingAuth
import com.timeflow.app.ui.screens.AppsScreen
import com.timeflow.app.ui.screens.HistoryScreen
import com.timeflow.app.ui.screens.HomeScreen
import com.timeflow.app.ui.screens.SecretScreen
import com.timeflow.app.ui.screens.SettingsScreen
import com.timeflow.app.ui.screens.StatsScreen
import com.timeflow.app.ui.theme.TimeFlowTheme
import com.timeflow.app.util.Formatter
import com.timeflow.app.util.LocalFormatter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.util.Locale

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as TimeFlowApp).container
        val prefs = container.preferencesRepository
        // Read once up front so the first frame already uses the saved language and theme.
        val initialLang = runBlocking { prefs.language.first() }
        val initialTheme = runBlocking { prefs.theme.first() }

        setContent {
            val lang by prefs.language.collectAsState(initial = initialLang)
            val theme by prefs.theme.collectAsState(initial = initialTheme)
            val localized = remember(lang) {
                val cfg = Configuration(resources.configuration)
                cfg.setLocale(Locale.forLanguageTag(lang))
                createConfigurationContext(cfg)
            }
            val fmt = remember(lang) { Formatter(localized, lang) }
            val dark = when (theme) {
                PreferencesRepository.THEME_DARK -> true
                PreferencesRepository.THEME_LIGHT -> false
                else -> isSystemInDarkTheme()
            }
            CompositionLocalProvider(
                LocalContext provides localized,
                LocalConfiguration provides localized.resources.configuration,
                LocalFormatter provides fmt
            ) {
                TimeFlowTheme(dark) { MainScreen(container, this@MainActivity) }
            }
        }
    }
}

private data class Tab(val labelRes: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun MainScreen(container: AppContainer, activity: FragmentActivity) {
    val tabs = remember {
        listOf(
            Tab(R.string.nav_home, Icons.Filled.Home),
            Tab(R.string.nav_apps, Icons.Filled.Menu),
            Tab(R.string.nav_stats, Icons.Filled.DateRange),
            Tab(R.string.nav_history, Icons.AutoMirrored.Filled.List),
            Tab(R.string.nav_settings, Icons.Filled.Settings)
        )
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    // Not saveable on purpose: rotating or leaving the app closes the secret screen.
    var showSecret by remember { mutableStateOf(false) }
    var pendingAuth by remember { mutableStateOf<PendingAuth?>(null) }
    var resumeTick by remember { mutableIntStateOf(0) }
    var granted by remember { mutableStateOf(container.usageSync.hasAccess()) }
    var syncing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun runSync() {
        if (syncing) return
        scope.launch {
            syncing = true
            granted = container.usageSync.hasAccess()
            try {
                container.usageSync.sync()
            } catch (_: Exception) {
                // Next sync will retry; stored history is untouched.
            }
            granted = container.usageSync.hasAccess()
            syncing = false
        }
    }

    DisposableEffect(activity) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> resumeTick++
                Lifecycle.Event.ON_STOP -> showSecret = false
                else -> Unit
            }
        }
        activity.lifecycle.addObserver(observer)
        onDispose { activity.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(resumeTick) { runSync() }

    val requestAuth: (() -> Unit) -> Unit = { action -> pendingAuth = PendingAuth(action) }
    val openSecret: () -> Unit = { requestAuth { showSecret = true } }

    if (showSecret) {
        BackHandler { showSecret = false }
        Scaffold { inner ->
            Box(Modifier.padding(inner).fillMaxSize()) {
                SecretScreen(container) { showSecret = false }
            }
        }
    } else {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(stringResource(t.labelRes)) }
                        )
                    }
                }
            }
        ) { inner ->
            Box(Modifier.padding(inner).fillMaxSize()) {
                Crossfade(targetState = tab, label = "tabs") { current ->
                    when (current) {
                        0 -> HomeScreen(
                            container, granted, syncing, resumeTick,
                            onGrant = { activity.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) },
                            onRefresh = ::runSync
                        )
                        1 -> AppsScreen(container, resumeTick, openSecret)
                        2 -> StatsScreen(container)
                        3 -> HistoryScreen(container)
                        else -> SettingsScreen(container, activity, openSecret, requestAuth)
                    }
                }
            }
        }
    }

    AuthHost(activity, container.preferencesRepository, pendingAuth) { pendingAuth = null }
}
