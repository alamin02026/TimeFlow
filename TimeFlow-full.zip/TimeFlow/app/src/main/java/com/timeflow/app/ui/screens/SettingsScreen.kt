package com.timeflow.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.timeflow.app.AppContainer
import com.timeflow.app.R
import com.timeflow.app.data.repo.PreferencesRepository
import com.timeflow.app.ui.PinSetupDialog
import com.timeflow.app.ui.ScreenTitle
import com.timeflow.app.ui.SettingsViewModel
import com.timeflow.app.ui.SoftCard
import com.timeflow.app.ui.canUseBiometric

@Composable
fun SettingsScreen(
    container: AppContainer,
    activity: FragmentActivity,
    onOpenSecret: () -> Unit,
    requestAuth: (() -> Unit) -> Unit
) {
    val vm = containerViewModel(container) { SettingsViewModel(it) }
    val language by vm.language.collectAsState(initial = PreferencesRepository.LANG_ENGLISH)
    val theme by vm.theme.collectAsState(initial = PreferencesRepository.THEME_SYSTEM)
    val biometric by vm.biometric.collectAsState(initial = false)
    val hasPin by vm.hasPin.collectAsState(initial = false)
    val query by vm.query.collectAsState()
    val revealed by vm.secret.revealed.collectAsState()
    val message by vm.message.collectAsState()
    val host = remember { SnackbarHostState() }
    val resolver = LocalContext.current.contentResolver
    var showPinSetup by remember { mutableStateOf(false) }
    val bioAvailable = remember { canUseBiometric(activity) }

    MessageEffect(message, host) { vm.consumeMessage() }

    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) vm.exportCsv(resolver, uri)
    }
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportBackup(resolver, uri)
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.restore(resolver, uri)
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { ScreenTitle(stringResource(R.string.nav_settings)) }
            item { SecretAwareSearchField(query, vm::onQuery) }
            item { SecretEntryCard(revealed, onOpenSecret) }

            item {
                SoftCard {
                    Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(language == PreferencesRepository.LANG_ENGLISH, { vm.setLanguage(PreferencesRepository.LANG_ENGLISH) },
                            { Text(stringResource(R.string.lang_en)) })
                        FilterChip(language == PreferencesRepository.LANG_BANGLA, { vm.setLanguage(PreferencesRepository.LANG_BANGLA) },
                            { Text(stringResource(R.string.lang_bn)) })
                    }
                }
            }
            item {
                SoftCard {
                    Text(stringResource(R.string.settings_theme), style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(theme == PreferencesRepository.THEME_SYSTEM, { vm.setTheme(PreferencesRepository.THEME_SYSTEM) },
                            { Text(stringResource(R.string.theme_system)) })
                        FilterChip(theme == PreferencesRepository.THEME_LIGHT, { vm.setTheme(PreferencesRepository.THEME_LIGHT) },
                            { Text(stringResource(R.string.theme_light)) })
                        FilterChip(theme == PreferencesRepository.THEME_DARK, { vm.setTheme(PreferencesRepository.THEME_DARK) },
                            { Text(stringResource(R.string.theme_dark)) })
                    }
                }
            }
            item {
                SoftCard {
                    Text(stringResource(R.string.settings_security), style = MaterialTheme.typography.titleMedium)
                    OutlinedButton(onClick = {
                        if (hasPin) requestAuth { showPinSetup = true } else showPinSetup = true
                    }) {
                        Text(stringResource(if (hasPin) R.string.settings_pin_change else R.string.settings_pin_set))
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.settings_biometric), Modifier.weight(1f))
                        Switch(
                            checked = biometric && bioAvailable,
                            enabled = bioAvailable && hasPin,
                            onCheckedChange = { vm.setBiometric(it) }
                        )
                    }
                    if (!bioAvailable) {
                        Text(
                            stringResource(R.string.biometric_unavailable),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            item {
                SoftCard {
                    Text(stringResource(R.string.settings_data), style = MaterialTheme.typography.titleMedium)
                    Button(onClick = { csvLauncher.launch("timeflow_usage.csv") }) {
                        Text(stringResource(R.string.export_csv))
                    }
                    Button(onClick = { backupLauncher.launch("timeflow_backup.json") }) {
                        Text(stringResource(R.string.backup_json))
                    }
                    OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }) {
                        Text(stringResource(R.string.restore_json))
                    }
                }
            }
            item {
                SoftCard {
                    Text(stringResource(R.string.settings_privacy), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.privacy_body), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        stringResource(R.string.perm_explain_usage),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        SnackbarHost(host, Modifier.align(Alignment.BottomCenter))
    }

    if (showPinSetup) {
        PinSetupDialog(
            onDismiss = { showPinSetup = false },
            onSave = { pin -> vm.savePin(pin); showPinSetup = false }
        )
    }
}
