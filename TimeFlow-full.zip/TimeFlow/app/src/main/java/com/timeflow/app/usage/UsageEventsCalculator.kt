package com.timeflow.app.usage

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Computes real foreground time per app per local day from Android usage events.
 * Sessions that cross midnight are split between the two days.
 * Read-only: nothing is written to Android's own statistics.
 */
object UsageEventsCalculator {
    private const val RESUMED = 1          // ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
    private const val PAUSED = 2           // ACTIVITY_PAUSED / MOVE_TO_BACKGROUND
    private const val SCREEN_OFF = 16      // SCREEN_NON_INTERACTIVE

    fun compute(
        context: Context,
        fromDay: Long,
        allowed: Set<String>
    ): Map<Long, Map<String, Long>> {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val zone = ZoneId.systemDefault()
        val start = LocalDate.ofEpochDay(fromDay).atStartOfDay(zone).toInstant().toEpochMilli()
        val now = System.currentTimeMillis()

        val result = HashMap<Long, HashMap<String, Long>>()
        val openActivities = HashMap<String, MutableSet<String>>()
        val openSince = HashMap<String, Long>()
        val seen = HashSet<String>()

        fun add(pkg: String, s: Long, e: Long) {
            var cursor = s
            while (cursor < e) {
                val date = Instant.ofEpochMilli(cursor).atZone(zone).toLocalDate()
                val dayEnd = date.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
                val segEnd = minOf(e, dayEnd)
                result.getOrPut(date.toEpochDay()) { HashMap() }
                    .merge(pkg, segEnd - cursor) { a, b -> a + b }
                cursor = segEnd
            }
        }

        val events = usm.queryEvents(start, now)
        val ev = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            val ts = ev.timeStamp
            val type = ev.eventType
            if (type == SCREEN_OFF) {
                openSince.forEach { (p, since) -> add(p, since, ts) }
                openSince.clear()
                openActivities.clear()
                continue
            }
            val pkg = ev.packageName ?: continue
            if (pkg !in allowed) continue
            val cls = ev.className ?: ""
            if (type == RESUMED) {
                seen.add(pkg)
                val set = openActivities.getOrPut(pkg) { HashSet() }
                if (set.isEmpty()) openSince[pkg] = ts
                set.add(cls)
            } else if (type == PAUSED) {
                val set = openActivities[pkg]
                if (set == null || (set.isEmpty() && openSince[pkg] == null)) {
                    // App was already in front when the window started.
                    if (pkg !in seen) add(pkg, start, ts)
                    seen.add(pkg)
                } else {
                    set.remove(cls)
                    if (set.isEmpty()) openSince.remove(pkg)?.let { add(pkg, it, ts) }
                }
            }
        }
        openSince.forEach { (p, since) -> add(p, since, now) }
        return result
    }
}
