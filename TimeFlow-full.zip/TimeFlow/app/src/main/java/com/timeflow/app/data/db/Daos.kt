package com.timeflow.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AppInfoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<AppInfoEntity>)

    @Query("SELECT * FROM app_info ORDER BY appName COLLATE NOCASE")
    fun observeAll(): Flow<List<AppInfoEntity>>

    @Query("SELECT * FROM app_info")
    suspend fun getAll(): List<AppInfoEntity>

    @Query("SELECT * FROM app_info WHERE packageName = :pkg")
    suspend fun get(pkg: String): AppInfoEntity?
}

@Dao
interface ActualUsageDao {
    @Query("SELECT * FROM actual_usage")
    suspend fun getAll(): List<ActualUsageEntity>

    @Query(
        "SELECT dateEpochDay, SUM(durationMs) AS totalMs FROM actual_usage " +
            "GROUP BY dateEpochDay ORDER BY dateEpochDay DESC"
    )
    fun observeAllDayTotals(): Flow<List<DayTotal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<ActualUsageEntity>)

    @Query("SELECT * FROM actual_usage WHERE dateEpochDay = :day")
    suspend fun forDay(day: Long): List<ActualUsageEntity>

    @Query("SELECT * FROM actual_usage WHERE dateEpochDay BETWEEN :from AND :to")
    fun observeRange(from: Long, to: Long): Flow<List<ActualUsageEntity>>

    @Query(
        "SELECT dateEpochDay, SUM(durationMs) AS totalMs FROM actual_usage " +
            "WHERE dateEpochDay BETWEEN :from AND :to GROUP BY dateEpochDay ORDER BY dateEpochDay"
    )
    fun observeDayTotals(from: Long, to: Long): Flow<List<DayTotal>>

    @Query("SELECT MIN(dateEpochDay) FROM actual_usage")
    suspend fun earliestDay(): Long?
}

@Dao
interface DemoProfileDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllReplace(items: List<DemoProfileEntity>)

    @Query("SELECT * FROM demo_profiles")
    suspend fun getAll(): List<DemoProfileEntity>

    @Insert
    suspend fun insert(profile: DemoProfileEntity): Long

    @Query("UPDATE demo_profiles SET isActive = 0")
    suspend fun deactivateAll()

    @Query("SELECT * FROM demo_profiles WHERE isActive = 1 ORDER BY id DESC LIMIT 1")
    fun observeActive(): Flow<DemoProfileEntity?>

    @Query("SELECT * FROM demo_profiles WHERE isActive = 1 ORDER BY id DESC LIMIT 1")
    suspend fun getActive(): DemoProfileEntity?

    @Query("SELECT COUNT(*) FROM demo_profiles")
    suspend fun count(): Int

    @Query("SELECT * FROM demo_profiles ORDER BY id DESC")
    fun observeAll(): Flow<List<DemoProfileEntity>>
}

@Dao
interface DemoAllocationDao {
    @Query("SELECT * FROM demo_allocations")
    suspend fun getAll(): List<DemoAllocationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<DemoAllocationEntity>)

    @Query("DELETE FROM demo_allocations WHERE dateEpochDay = :day")
    suspend fun deleteForDay(day: Long)

    @Query("SELECT * FROM demo_allocations WHERE dateEpochDay = :day ORDER BY allocatedMinutes DESC")
    suspend fun forDay(day: Long): List<DemoAllocationEntity>

    @Query("SELECT * FROM demo_allocations WHERE dateEpochDay = :day ORDER BY allocatedMinutes DESC")
    fun observeDay(day: Long): Flow<List<DemoAllocationEntity>>

    @Query("SELECT * FROM demo_allocations WHERE dateEpochDay BETWEEN :from AND :to")
    fun observeRange(from: Long, to: Long): Flow<List<DemoAllocationEntity>>
}

@Dao
interface DailySnapshotDao {
    @Query("SELECT * FROM daily_snapshots")
    suspend fun getAll(): List<DailySnapshotEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(snapshot: DailySnapshotEntity)

    @Query("SELECT * FROM daily_snapshots WHERE dateEpochDay = :day")
    suspend fun get(day: Long): DailySnapshotEntity?

    @Query("SELECT * FROM daily_snapshots WHERE dateEpochDay BETWEEN :from AND :to ORDER BY dateEpochDay")
    fun observeRange(from: Long, to: Long): Flow<List<DailySnapshotEntity>>

    @Query("SELECT * FROM daily_snapshots ORDER BY dateEpochDay DESC")
    fun observeAll(): Flow<List<DailySnapshotEntity>>
}
