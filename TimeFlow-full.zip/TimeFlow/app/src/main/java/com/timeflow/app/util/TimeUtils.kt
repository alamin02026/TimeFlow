package com.timeflow.app.util

import java.time.LocalDate

object TimeUtils {
    fun today(): Long = LocalDate.now().toEpochDay()

    /** Monday of the week that contains [day]. */
    fun weekStart(day: Long): Long {
        val d = LocalDate.ofEpochDay(day)
        return d.minusDays((d.dayOfWeek.value - 1).toLong()).toEpochDay()
    }

    fun monthRange(day: Long, offsetMonths: Int): Pair<Long, Long> {
        val first = LocalDate.ofEpochDay(day).withDayOfMonth(1).plusMonths(offsetMonths.toLong())
        return first.toEpochDay() to first.plusMonths(1).minusDays(1).toEpochDay()
    }

    fun yearRange(day: Long, offsetYears: Int): Pair<Long, Long> {
        val year = LocalDate.ofEpochDay(day).year + offsetYears
        return LocalDate.of(year, 1, 1).toEpochDay() to LocalDate.of(year, 12, 31).toEpochDay()
    }
}
