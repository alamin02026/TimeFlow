package com.timeflow.app.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.timeflow.app.TimeFlowApp

/** Saves usage in the background so history keeps growing even if the app is not opened. */
class DailySyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        (applicationContext as TimeFlowApp).container.usageSync.sync()
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }
}
