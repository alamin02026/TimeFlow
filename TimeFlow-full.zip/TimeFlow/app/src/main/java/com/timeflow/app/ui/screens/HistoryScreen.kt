package com.timeflow.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.timeflow.app.AppContainer
import com.timeflow.app.R
import com.timeflow.app.ui.DemoBadge
import com.timeflow.app.ui.EmptyState
import com.timeflow.app.ui.HistoryViewModel
import com.timeflow.app.ui.ScreenTitle
import com.timeflow.app.ui.SoftCard
import com.timeflow.app.ui.rememberFmt

@Composable
fun HistoryScreen(container: AppContainer) {
    val vm = containerViewModel(container) { HistoryViewModel(it) }
    val ui by vm.ui.collectAsState()
    val expanded by vm.expanded.collectAsState()
    val details by vm.details.collectAsState()
    val fmt = rememberFmt()
    val data = ui

    if (data == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenTitle(stringResource(R.string.nav_history)) }
        if (data.days.isEmpty()) {
            item { EmptyState(stringResource(R.string.history_empty)) }
        } else {
            item {
                SoftCard {
                    Text(stringResource(R.string.history_lifetime_total), style = MaterialTheme.typography.labelMedium)
                    Text(
                        fmt.duration(data.totalMs),
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(stringResource(R.string.history_days_tracked) + ": " + fmt.num(data.days.size))
                    data.firstDay?.let { Text(stringResource(R.string.history_since) + ": " + fmt.dateLabel(it)) }
                    Text(stringResource(R.string.history_avg) + ": " + fmt.duration(data.avgMs))
                }
            }
            items(data.days, key = { it.day }) { d ->
                SoftCard(Modifier.clickable { vm.toggle(d.day) }) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(fmt.dateLabel(d.day), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        Text(fmt.duration(d.realMs), fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    }
                    if (d.demoMin != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DemoBadge()
                            Text(
                                stringResource(R.string.history_demo_limit) + ": " + fmt.minutes(d.demoMin),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    AnimatedVisibility(visible = expanded == d.day) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            details.forEach { x ->
                                Row(Modifier.fillMaxWidth()) {
                                    Text(x.name, Modifier.weight(1f), maxLines = 1)
                                    Text(fmt.duration(x.realMs))
                                    if (x.demoMin > 0) {
                                        Text("  ·  " + stringResource(R.string.demo_label) + " " + fmt.minutes(x.demoMin),
                                            color = MaterialTheme.colorScheme.tertiary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
