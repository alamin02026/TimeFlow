package com.timeflow.app.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Installed application information. */
@Entity(tableName = "app_info")
data class AppInfoEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val isSystemApp: Boolean,
    val firstSeenAt: Long,
    val updatedAt: Long
)

/** Real usage from Android UsageStatsManager: one row per app per day. Never edited by demo features. */
@Entity(
    tableName = "actual_usage",
    indices = [Index(value = ["packageName", "dateEpochDay"], unique = true), Index("dateEpochDay")]
)
data class ActualUsageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val dateEpochDay: Long,
    val durationMs: Long,
    val recordedAt: Long
)

/** A demo configuration (daily limit). Old profiles are kept, only one is active. */
@Entity(tableName = "demo_profiles")
data class DemoProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val totalMinutes: Int,
    val method: String = METHOD_WEIGHTED,
    val isActive: Boolean,
    val createdAt: Long
) {
    companion object {
        const val METHOD_WEIGHTED = "WEIGHTED"
    }
}

/** Demo minutes given to an app on a day. Always a Demo value, never real usage. */
@Entity(
    tableName = "demo_allocations",
    indices = [Index(value = ["dateEpochDay", "packageName"], unique = true), Index("profileId")]
)
data class DemoAllocationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val dateEpochDay: Long,
    val packageName: String,
    val weightMs: Long,
    val allocatedMinutes: Int
)

/** One summary row per day, kept forever. */
@Entity(tableName = "daily_snapshots")
data class DailySnapshotEntity(
    @PrimaryKey val dateEpochDay: Long,
    val totalActualMs: Long,
    val demoProfileId: Long?,
    val demoTotalMinutes: Int,
    val createdAt: Long
)

data class DayTotal(val dateEpochDay: Long, val totalMs: Long)
