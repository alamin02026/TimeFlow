package com.timeflow.app.util

import android.content.Context
import androidx.compose.runtime.compositionLocalOf
import com.timeflow.app.R
import java.time.LocalDate
import java.time.Month
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.time.format.TextStyle
import java.util.Locale

/** Language-aware formatting (Bangla digits, month names, durations). */
class Formatter(private val context: Context, val lang: String) {
    private val locale: Locale = Locale.forLanguageTag(lang)

    fun digits(s: String): String =
        if (lang != "bn") s else buildString {
            s.forEach { append(if (it in '0'..'9') '০' + (it - '0') else it) }
        }

    fun num(n: Number): String = digits(n.toString())

    fun minutes(total: Int): String {
        val h = total / 60
        val m = total % 60
        return digits(
            when {
                h > 0 && m > 0 -> context.getString(R.string.dur_hm, h, m)
                h > 0 -> context.getString(R.string.dur_h, h)
                else -> context.getString(R.string.dur_m, m)
            }
        )
    }

    fun duration(ms: Long): String {
        val min = (ms / 60_000L).toInt()
        return if (ms > 0 && min == 0) digits(context.getString(R.string.dur_lt1)) else minutes(min)
    }

    fun weekdayShort(day: Long): String =
        LocalDate.ofEpochDay(day).dayOfWeek.getDisplayName(TextStyle.SHORT, locale)

    fun dateLabel(day: Long): String = digits(
        DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(locale)
            .format(LocalDate.ofEpochDay(day))
    )

    fun monthShort(month: Int): String = Month.of(month).getDisplayName(TextStyle.SHORT, locale)

    fun monthYear(day: Long): String {
        val d = LocalDate.ofEpochDay(day)
        return digits("${d.month.getDisplayName(TextStyle.FULL, locale)} ${d.year}")
    }

    fun year(day: Long): String = num(LocalDate.ofEpochDay(day).year)
}

val LocalFormatter = compositionLocalOf<Formatter> { error("Formatter not provided") }
