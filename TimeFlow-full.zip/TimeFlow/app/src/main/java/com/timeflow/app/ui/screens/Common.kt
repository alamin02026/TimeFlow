package com.timeflow.app.ui.screens

import android.content.Context
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.timeflow.app.AppContainer
import com.timeflow.app.ui.Msg

@Composable
inline fun <reified T : ViewModel> containerViewModel(
    container: AppContainer,
    crossinline create: (AppContainer) -> T
): T = viewModel(factory = viewModelFactory { initializer { create(container) } })

fun Context.msgText(m: Msg): String = if (m.arg == null) getString(m.id) else getString(m.id, m.arg)

/** Shows [message] in the snackbar, then calls [consume]. */
@Composable
fun MessageEffect(message: Msg?, host: SnackbarHostState, consume: () -> Unit) {
    val context = LocalContext.current
    LaunchedEffect(message) {
        if (message != null) {
            host.showSnackbar(context.msgText(message))
            consume()
        }
    }
}
