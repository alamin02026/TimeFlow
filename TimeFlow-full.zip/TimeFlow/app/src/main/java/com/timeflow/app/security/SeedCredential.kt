package com.timeflow.app.security

/**
 * First-run credential for the secret configuration.
 * Only a salted PBKDF2 hash is stored here, never the code itself.
 * On first launch it is copied into DataStore, and the user can change it later.
 */
internal object SeedCredential {
    const val SALT_HEX = "731d19675a4c09ec464e97c09dd240e8"
    const val HASH_HEX = "0f0b48c793539a0f9d87b4161d92677db757da6d1e36fa8121dbd4bf50a4e33b"
}
