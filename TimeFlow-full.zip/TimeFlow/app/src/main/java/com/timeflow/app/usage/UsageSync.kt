package com.timeflow.app.usage

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.timeflow.app.data.db.ActualUsageEntity
import com.timeflow.app.data.db.AppInfoEntity
import com.timeflow.app.data.repo.ActualUsageRepository
import com.timeflow.app.data.repo.AppInfoRepository
import com.timeflow.app.data.repo.DemoAllocationRepository
import com.timeflow.app.util.TimeUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class SyncResult { OK, NO_PERMISSION, SKIPPED }

/** Reads real usage from Android and saves it permanently in Room with low CPU/battery impact. */
class UsageSync(
    private val context: Context,
    private val appInfoRepo: AppInfoRepository,
    private val usageRepo: ActualUsageRepository,
    private val demoRepo: DemoAllocationRepository
) {
    @Volatile
    private var lastSyncAtMs: Long = 0L

    @Volatile
    private var appsRefreshedThisSession: Boolean = false

    fun hasAccess(): Boolean = UsageAccess.isGranted(context)

    /** Saves installed apps (cached per session unless [force] is true to reduce PackageManager load). */
    suspend fun refreshApps(force: Boolean = false): List<AppInfoEntity> = withContext(Dispatchers.IO) {
        val existingList = appInfoRepo.getAll()
        if (appsRefreshedThisSession && !force && existingList.isNotEmpty()) {
            return@withContext existingList
        }
        val pm = context.packageManager
        val existing = existingList.associateBy { it.packageName }
        val now = System.currentTimeMillis()
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = pm.queryIntentActivities(launcher, 0)
            .distinctBy { it.activityInfo.packageName }
            .map { ri ->
                val info = ri.activityInfo.applicationInfo
                val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                AppInfoEntity(
                    packageName = ri.activityInfo.packageName,
                    appName = ri.loadLabel(pm).toString(),
                    isSystemApp = isSystem,
                    firstSeenAt = existing[ri.activityInfo.packageName]?.firstSeenAt ?: now,
                    updatedAt = now
                )
            }
        appInfoRepo.saveAll(found)
        appsRefreshedThisSession = true
        found
    }

    private fun homePackage(): String? {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return context.packageManager
            .resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
    }

    /**
     * Imports real usage efficiently:
     * - Skips automatic re-sync if synced within the last 2 minutes (unless [force] is true).
     * - Scans 14 days only on the first run; subsequent syncs scan only the last 2 days to stay fast & cool.
     */
    suspend fun sync(daysBack: Int = 14, force: Boolean = false): SyncResult = withContext(Dispatchers.Default) {
        val nowMs = System.currentTimeMillis()
        if (!force && lastSyncAtMs > 0L && (nowMs - lastSyncAtMs) < MIN_AUTO_SYNC_INTERVAL_MS) {
            return@withContext SyncResult.SKIPPED
        }

        val apps = refreshApps(force = force)
        if (!hasAccess()) return@withContext SyncResult.NO_PERMISSION

        val today = TimeUtils.today()
        val hasHistory = usageRepo.earliestDay() != null
        val effectiveDays = if (hasHistory && !force) minOf(daysBack, 2) else daysBack
        val from = today - (effectiveDays - 1)
        val allowed = apps.map { it.packageName }.toSet() - setOfNotNull(homePackage())
        val computed = UsageEventsCalculator.compute(context, from, allowed)
        val now = System.currentTimeMillis()

        for ((day, perApp) in computed) {
            if (day < from || day > today) continue
            val existing = usageRepo.forDay(day).associateBy { it.packageName }
            val rows = perApp.filter { it.value > 0 }.map { (pkg, ms) ->
                val old = existing[pkg]?.durationMs ?: 0L
                ActualUsageEntity(
                    id = existing[pkg]?.id ?: 0,
                    packageName = pkg,
                    dateEpochDay = day,
                    durationMs = maxOf(ms, old),
                    recordedAt = now
                )
            }
            if (rows.isNotEmpty()) usageRepo.saveAll(rows)
            if (rows.isNotEmpty() && (day == today || !demoRepo.hasReport(day))) {
                demoRepo.generateForDay(day)
            }
        }
        if (!demoRepo.hasReport(today)) demoRepo.generateForDay(today)
        lastSyncAtMs = System.currentTimeMillis()
        SyncResult.OK
    }

    companion object {
        private const val MIN_AUTO_SYNC_INTERVAL_MS = 2 * 60_000L // 2 minutes cooldown
    }
}
