package com.timeflow.app.usage

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.timeflow.app.data.db.ActualUsageEntity
import com.timeflow.app.data.db.AppInfoEntity
import com.timeflow.app.data.repo.ActualUsageRepository
import com.timeflow.app.data.repo.AppInfoRepository
import com.timeflow.app.data.repo.DemoAllocationRepository
import com.timeflow.app.util.TimeUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class SyncResult { OK, NO_PERMISSION }

/** Reads real usage from Android and saves it permanently in Room. */
class UsageSync(
    private val context: Context,
    private val appInfoRepo: AppInfoRepository,
    private val usageRepo: ActualUsageRepository,
    private val demoRepo: DemoAllocationRepository
) {
    fun hasAccess(): Boolean = UsageAccess.isGranted(context)

    /** Saves installed apps (also works without usage access, so the Apps list is never empty). */
    suspend fun refreshApps(): List<AppInfoEntity> = withContext(Dispatchers.Default) {
        val pm = context.packageManager
        val existing = appInfoRepo.getAll().associateBy { it.packageName }
        val now = System.currentTimeMillis()
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = pm.queryIntentActivities(launcher, 0)
            .distinctBy { it.activityInfo.packageName }
            .map { ri ->
                val info = ri.activityInfo.applicationInfo
                val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                AppInfoEntity(
                    packageName = ri.activityInfo.packageName,
                    appName = ri.loadLabel(pm).toString(),
                    isSystemApp = isSystem,
                    firstSeenAt = existing[ri.activityInfo.packageName]?.firstSeenAt ?: now,
                    updatedAt = now
                )
            }
        appInfoRepo.saveAll(found)
        found
    }

    private fun homePackage(): String? {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return context.packageManager
            .resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
    }

    /**
     * Imports real usage for the last [daysBack] days.
     * Existing values are never lowered, so history survives Android's own cleanup.
     * A Demo report is created for days that have none; today's is refreshed.
     */
    suspend fun sync(daysBack: Int = 14): SyncResult = withContext(Dispatchers.Default) {
        val apps = refreshApps()
        if (!hasAccess()) return@withContext SyncResult.NO_PERMISSION

        val today = TimeUtils.today()
        val from = today - (daysBack - 1)
        val allowed = apps.map { it.packageName }.toSet() - setOfNotNull(homePackage())
        val computed = UsageEventsCalculator.compute(context, from, allowed)
        val now = System.currentTimeMillis()

        for ((day, perApp) in computed) {
            if (day < from || day > today) continue
            val existing = usageRepo.forDay(day).associateBy { it.packageName }
            val rows = perApp.filter { it.value > 0 }.map { (pkg, ms) ->
                val old = existing[pkg]?.durationMs ?: 0L
                ActualUsageEntity(
                    id = existing[pkg]?.id ?: 0,
                    packageName = pkg,
                    dateEpochDay = day,
                    durationMs = maxOf(ms, old),
                    recordedAt = now
                )
            }
            if (rows.isNotEmpty()) usageRepo.saveAll(rows)
            if (rows.isNotEmpty() && (day == today || !demoRepo.hasReport(day))) {
                demoRepo.generateForDay(day)
            }
        }
        if (!demoRepo.hasReport(today)) demoRepo.generateForDay(today)
        SyncResult.OK
    }
}
