package com.timeflow.app.data.repo

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.timeflow.app.security.SecretCodeVerifier
import com.timeflow.app.security.SeedCredential
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "timeflow_prefs")

/** User preferences and credentials, stored locally with DataStore. Only hashes are kept for codes. */
class PreferencesRepository(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val THEME = stringPreferencesKey("theme")
        val SECRET_SALT = stringPreferencesKey("secret_salt")
        val SECRET_HASH = stringPreferencesKey("secret_hash")
        val PIN_SALT = stringPreferencesKey("pin_salt")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val BIOMETRIC = booleanPreferencesKey("biometric_enabled")
    }

    private val store get() = context.dataStore

    val language: Flow<String> = store.data.map { it[Keys.LANGUAGE] ?: LANG_ENGLISH }
    val theme: Flow<String> = store.data.map { it[Keys.THEME] ?: THEME_SYSTEM }
    val biometricEnabled: Flow<Boolean> = store.data.map { it[Keys.BIOMETRIC] ?: false }
    val hasPin: Flow<Boolean> = store.data.map { it[Keys.PIN_HASH] != null }

    suspend fun setLanguage(value: String) { store.edit { it[Keys.LANGUAGE] = value } }
    suspend fun setTheme(value: String) { store.edit { it[Keys.THEME] = value } }
    suspend fun setBiometricEnabled(value: Boolean) { store.edit { it[Keys.BIOMETRIC] = value } }

    /** Copies the first-run secret credential into DataStore (once). */
    suspend fun ensureSeeded() {
        store.edit {
            if (it[Keys.SECRET_HASH] == null) {
                it[Keys.SECRET_SALT] = SeedCredential.SALT_HEX
                it[Keys.SECRET_HASH] = SeedCredential.HASH_HEX
            }
        }
    }

    /** True if [input] matches the secret access code typed in the search box. */
    suspend fun verifySecretCode(input: String): Boolean {
        val prefs = store.data.first()
        val salt = prefs[Keys.SECRET_SALT] ?: return false
        val hash = prefs[Keys.SECRET_HASH] ?: return false
        return SecretCodeVerifier.verify(input.trim(), SecretCodeVerifier.fromHex(salt), SecretCodeVerifier.fromHex(hash))
    }

    suspend fun changeSecretCode(newCode: String) {
        val salt = SecretCodeVerifier.newSalt()
        val hash = SecretCodeVerifier.hash(newCode, salt)
        store.edit {
            it[Keys.SECRET_SALT] = SecretCodeVerifier.toHex(salt)
            it[Keys.SECRET_HASH] = SecretCodeVerifier.toHex(hash)
        }
    }

    suspend fun setPin(pin: String) {
        val salt = SecretCodeVerifier.newSalt()
        val hash = SecretCodeVerifier.hash(pin, salt)
        store.edit {
            it[Keys.PIN_SALT] = SecretCodeVerifier.toHex(salt)
            it[Keys.PIN_HASH] = SecretCodeVerifier.toHex(hash)
        }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val prefs = store.data.first()
        val salt = prefs[Keys.PIN_SALT] ?: return false
        val hash = prefs[Keys.PIN_HASH] ?: return false
        return SecretCodeVerifier.verify(pin, SecretCodeVerifier.fromHex(salt), SecretCodeVerifier.fromHex(hash))
    }

    companion object {
        const val LANG_ENGLISH = "en"
        const val LANG_BANGLA = "bn"
        const val THEME_SYSTEM = "system"
        const val THEME_LIGHT = "light"
        const val THEME_DARK = "dark"
    }
}
