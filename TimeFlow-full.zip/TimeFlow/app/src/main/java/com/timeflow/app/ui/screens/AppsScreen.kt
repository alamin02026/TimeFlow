package com.timeflow.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.timeflow.app.AppContainer
import com.timeflow.app.R
import com.timeflow.app.ui.AppsViewModel
import com.timeflow.app.ui.DemoBadge
import com.timeflow.app.ui.EmptyState
import com.timeflow.app.ui.ScreenTitle
import com.timeflow.app.ui.SoftCard
import com.timeflow.app.ui.StatMode
import com.timeflow.app.ui.UsageRow
import com.timeflow.app.ui.rememberFmt

/** Reusable search box. Typing the secret access code reveals the Secret Configuration entry. */
@Composable
fun SecretAwareSearchField(query: String, onQuery: (String) -> Unit) {
    OutlinedTextField(
        value = query,
        onValueChange = onQuery,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = MaterialTheme.shapes.large,
        placeholder = { Text(stringResource(R.string.apps_search_hint)) },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQuery("") }) {
                    Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.clear))
                }
            }
        }
    )
}

@Composable
fun SecretEntryCard(visible: Boolean, onOpen: () -> Unit) {
    AnimatedVisibility(visible = visible) {
        SoftCard(Modifier.clickable(onClick = onOpen)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.secret_entry_title), style = MaterialTheme.typography.titleMedium)
                    Text(
                        stringResource(R.string.secret_entry_body),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun AppsScreen(container: AppContainer, resumeTick: Int, onOpenSecret: () -> Unit) {
    val vm = containerViewModel(container) { AppsViewModel(it) }
    LaunchedEffect(resumeTick) { vm.refreshDay() }
    val rows by vm.rows.collectAsState()
    val query by vm.query.collectAsState()
    val mode by vm.mode.collectAsState()
    val revealed by vm.secret.revealed.collectAsState()
    val fmt = rememberFmt()

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenTitle(stringResource(R.string.nav_apps))
        SecretAwareSearchField(query, vm::onQuery)
        SecretEntryCard(revealed, onOpenSecret)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(
                selected = mode == StatMode.REAL,
                onClick = { vm.mode.value = StatMode.REAL },
                label = { Text(stringResource(R.string.mode_real)) }
            )
            FilterChip(
                selected = mode == StatMode.DEMO,
                onClick = { vm.mode.value = StatMode.DEMO },
                label = { Text(stringResource(R.string.mode_demo)) }
            )
            if (mode == StatMode.DEMO) DemoBadge()
        }
        val list = rows
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> EmptyState(
                stringResource(if (query.isBlank()) R.string.apps_empty else R.string.apps_no_match)
            )
            else -> {
                val max = list.maxOf { if (mode == StatMode.REAL) it.realMs else it.demoMin * 60_000L }
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(list, key = { it.pkg }) { a ->
                        val value = if (mode == StatMode.REAL) a.realMs else a.demoMin * 60_000L
                        UsageRow(
                            a.pkg, a.name, value, max,
                            if (mode == StatMode.REAL) fmt.duration(a.realMs) else fmt.minutes(a.demoMin)
                        )
                    }
                }
            }
        }
    }
}
