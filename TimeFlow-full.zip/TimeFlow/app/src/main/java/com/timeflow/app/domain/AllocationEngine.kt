package com.timeflow.app.domain

/**
 * Weighted allocation:
 *   allocated = totalMinutes * weight / totalWeight
 * Whole minutes are produced with the largest-remainder method, so the
 * allocated minutes always add up to exactly [totalMinutes].
 */
object AllocationEngine {

    private data class Share(val key: String, val weight: Long, val base: Int, val remainder: Long)

    /**
     * @param totalMinutes configured demo limit in minutes (>= 0)
     * @param weights key (package name) to weight (real usage in ms). Negative values count as 0.
     *        If every weight is 0, all keys are treated as equal.
     * @return key to whole minutes. Empty if [weights] is empty.
     */
    fun allocate(totalMinutes: Int, weights: Map<String, Long>): Map<String, Int> {
        require(totalMinutes >= 0) { "totalMinutes must be >= 0" }
        if (weights.isEmpty()) return emptyMap()

        val cleaned = weights.mapValues { maxOf(it.value, 0L) }
        val effective =
            if (cleaned.values.sum() == 0L) cleaned.mapValues { 1L } else cleaned
        val weightSum = effective.values.sum()

        val shares = effective.map { (key, weight) ->
            val numerator = totalMinutes.toLong() * weight
            Share(key, weight, (numerator / weightSum).toInt(), numerator % weightSum)
        }

        val leftover = totalMinutes - shares.sumOf { it.base }
        val winners = shares
            .sortedWith(
                compareByDescending<Share> { it.remainder }
                    .thenByDescending { it.weight }
                    .thenBy { it.key }
            )
            .take(leftover)
            .map { it.key }
            .toSet()

        return shares.associate { it.key to it.base + if (it.key in winners) 1 else 0 }
    }

    fun hoursAndMinutes(totalMinutes: Int): Pair<Int, Int> = totalMinutes / 60 to totalMinutes % 60
}
