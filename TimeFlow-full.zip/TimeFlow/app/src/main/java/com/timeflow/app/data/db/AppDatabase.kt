package com.timeflow.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        AppInfoEntity::class,
        ActualUsageEntity::class,
        DemoProfileEntity::class,
        DemoAllocationEntity::class,
        DailySnapshotEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appInfoDao(): AppInfoDao
    abstract fun actualUsageDao(): ActualUsageDao
    abstract fun demoProfileDao(): DemoProfileDao
    abstract fun demoAllocationDao(): DemoAllocationDao
    abstract fun dailySnapshotDao(): DailySnapshotDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "timeflow.db")
                .build()
    }
}
