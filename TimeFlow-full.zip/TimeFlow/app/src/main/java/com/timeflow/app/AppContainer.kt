package com.timeflow.app

import android.content.Context
import com.timeflow.app.data.db.AppDatabase
import com.timeflow.app.data.repo.ActualUsageRepository
import com.timeflow.app.data.repo.AppInfoRepository
import com.timeflow.app.data.repo.DailySnapshotRepository
import com.timeflow.app.data.repo.DemoAllocationRepository
import com.timeflow.app.data.repo.DemoProfileRepository
import com.timeflow.app.data.repo.PreferencesRepository
import com.timeflow.app.backup.BackupManager
import com.timeflow.app.usage.UsageSync

/** Simple manual dependency container shared by the whole app. */
class AppContainer(context: Context) {
    val database: AppDatabase = AppDatabase.create(context)

    val appInfoRepository = AppInfoRepository(database.appInfoDao())
    val actualUsageRepository = ActualUsageRepository(database.actualUsageDao())
    val demoProfileRepository = DemoProfileRepository(database, database.demoProfileDao())
    val demoAllocationRepository = DemoAllocationRepository(
        database,
        database.actualUsageDao(),
        database.appInfoDao(),
        database.demoProfileDao(),
        database.demoAllocationDao(),
        database.dailySnapshotDao()
    )
    val dailySnapshotRepository = DailySnapshotRepository(database.dailySnapshotDao())
    val preferencesRepository = PreferencesRepository(context.applicationContext)
    val usageSync = UsageSync(
        context.applicationContext,
        appInfoRepository,
        actualUsageRepository,
        demoAllocationRepository
    )
    val backupManager = BackupManager(database)
}
