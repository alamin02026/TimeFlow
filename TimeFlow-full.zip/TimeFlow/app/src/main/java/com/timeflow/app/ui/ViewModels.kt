package com.timeflow.app.ui

import android.content.ContentResolver
import android.net.Uri
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.timeflow.app.AppContainer
import com.timeflow.app.R
import com.timeflow.app.data.db.ActualUsageEntity
import com.timeflow.app.data.db.DemoAllocationEntity
import com.timeflow.app.data.repo.DemoResult
import com.timeflow.app.data.repo.PreferencesRepository
import com.timeflow.app.util.TimeUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

// ---------- shared models ----------

data class Msg(@StringRes val id: Int, val arg: Int? = null)
data class AppValue(val pkg: String, val name: String, val ms: Long)

private fun usageRows(rows: List<ActualUsageEntity>) = rows.map { Triple(it.dateEpochDay, it.packageName, it.durationMs) }
private fun demoRows(rows: List<DemoAllocationEntity>) =
    rows.map { Triple(it.dateEpochDay, it.packageName, it.allocatedMinutes * 60_000L) }

private fun sumByApp(rows: List<Triple<Long, String, Long>>, names: Map<String, String>): List<AppValue> =
    rows.groupBy { it.second }
        .map { (pkg, list) -> AppValue(pkg, names[pkg] ?: pkg, list.sumOf { it.third }) }
        .filter { it.ms > 0 }
        .sortedByDescending { it.ms }

/** Finds out whether the text typed in a search box equals the secret access code. */
class SecretSearch(private val prefs: PreferencesRepository, private val scope: kotlinx.coroutines.CoroutineScope) {
    private val _revealed = MutableStateFlow(false)
    val revealed: StateFlow<Boolean> = _revealed.asStateFlow()
    private var job: Job? = null

    fun onQuery(raw: String) {
        job?.cancel()
        val q = raw.trim()
        if (q.length < 6 || q.length > 32) {
            _revealed.value = false
            return
        }
        job = scope.launch {
            delay(250)
            val normalized = q.filter { it.isLetterOrDigit() }
            val ok = withContext(Dispatchers.Default) {
                prefs.verifySecretCode(q) || (normalized != q && normalized.length >= 6 && prefs.verifySecretCode(normalized))
            }
            _revealed.value = ok
        }
    }

    fun hide() {
        job?.cancel()
        _revealed.value = false
    }
}

// ---------- Home ----------

data class HomeUi(
    val realTotalMs: Long = 0,
    val realTop: List<AppValue> = emptyList(),
    val demoTotalMin: Int = 0,
    val demoTop: List<AppValue> = emptyList(),
    val limitMin: Int = 0,
    val last7: List<Pair<Long, Long>> = emptyList()
)

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModel(private val c: AppContainer) : ViewModel() {
    private val today = MutableStateFlow(TimeUtils.today())
    fun refreshDay() { today.value = TimeUtils.today() }

    val ui: StateFlow<HomeUi> = today.flatMapLatest { day ->
        combine(
            c.appInfoRepository.apps,
            c.actualUsageRepository.observeRange(day, day),
            c.demoAllocationRepository.observeDay(day),
            c.actualUsageRepository.observeDayTotals(day - 6, day),
            c.demoProfileRepository.activeProfile
        ) { apps, real, demo, totals, profile ->
            val names = apps.associate { it.packageName to it.appName }
            val byDay = totals.associate { it.dateEpochDay to it.totalMs }
            HomeUi(
                realTotalMs = real.sumOf { it.durationMs },
                realTop = sumByApp(usageRows(real), names).take(5),
                demoTotalMin = demo.sumOf { it.allocatedMinutes },
                demoTop = sumByApp(demoRows(demo), names).take(5),
                limitMin = profile?.totalMinutes ?: 0,
                last7 = (day - 6..day).map { it to (byDay[it] ?: 0L) }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUi())
}

// ---------- Apps ----------

enum class StatMode { REAL, DEMO }
data class AppRowUi(val pkg: String, val name: String, val realMs: Long, val demoMin: Int)

@OptIn(ExperimentalCoroutinesApi::class)
class AppsViewModel(private val c: AppContainer) : ViewModel() {
    private val today = MutableStateFlow(TimeUtils.today())
    fun refreshDay() { today.value = TimeUtils.today() }

    val query = MutableStateFlow("")
    val mode = MutableStateFlow(StatMode.REAL)
    val secret = SecretSearch(c.preferencesRepository, viewModelScope)

    fun onQuery(q: String) { query.value = q; secret.onQuery(q) }

    val rows: StateFlow<List<AppRowUi>?> = today.flatMapLatest { day ->
        combine(
            c.appInfoRepository.apps,
            c.actualUsageRepository.observeRange(day, day),
            c.demoAllocationRepository.observeDay(day),
            mode,
            query
        ) { apps, real, demo, m, q ->
            val realBy = real.associate { it.packageName to it.durationMs }
            val demoBy = demo.associate { it.packageName to it.allocatedMinutes }
            val term = q.trim()
            apps.map { AppRowUi(it.packageName, it.appName, realBy[it.packageName] ?: 0L, demoBy[it.packageName] ?: 0) }
                .filter { term.isEmpty() || it.name.contains(term, true) || it.pkg.contains(term, true) }
                .sortedWith(
                    compareByDescending<AppRowUi> { if (m == StatMode.REAL) it.realMs else it.demoMin.toLong() }
                        .thenBy { it.name.lowercase() }
                )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
}

// ---------- Stats ----------

enum class Period { DAY, WEEK, MONTH, YEAR }
data class Bucket(val key: Long, val ms: Long)
data class StatsUi(
    val period: Period = Period.WEEK,
    val rangeStart: Long = 0,
    val rangeEnd: Long = 0,
    val totalMs: Long = 0,
    val avgMs: Long = 0,
    val buckets: List<Bucket> = emptyList(),
    val apps: List<AppValue> = emptyList()
)

@OptIn(ExperimentalCoroutinesApi::class)
class StatsViewModel(private val c: AppContainer) : ViewModel() {
    val period = MutableStateFlow(Period.WEEK)
    val mode = MutableStateFlow(StatMode.REAL)
    val offset = MutableStateFlow(0)

    fun setPeriod(p: Period) { period.value = p; offset.value = 0 }
    fun setMode(m: StatMode) { mode.value = m }
    fun previous() { offset.value -= 1 }
    fun next() { if (offset.value < 0) offset.value += 1 }

    private fun range(p: Period, o: Int): Pair<Long, Long> {
        val today = TimeUtils.today()
        return when (p) {
            Period.DAY -> (today + o) to (today + o)
            Period.WEEK -> TimeUtils.weekStart(today).let { (it + 7L * o) to (it + 7L * o + 6) }
            Period.MONTH -> TimeUtils.monthRange(today, o)
            Period.YEAR -> TimeUtils.yearRange(today, o)
        }
    }

    val ui: StateFlow<StatsUi> = combine(period, mode, offset) { p, m, o -> Triple(p, m, o) }
        .flatMapLatest { (p, m, o) ->
            val (from, to) = range(p, o)
            val rowsFlow = if (m == StatMode.REAL) {
                c.actualUsageRepository.observeRange(from, to).map { usageRows(it) }
            } else {
                c.demoAllocationRepository.observeRange(from, to).map { demoRows(it) }
            }
            combine(rowsFlow, c.appInfoRepository.apps) { rows, apps ->
                val names = apps.associate { it.packageName to it.appName }
                val total = rows.sumOf { it.third }
                val buckets = when (p) {
                    Period.DAY -> emptyList()
                    Period.WEEK, Period.MONTH -> {
                        val byDay = rows.groupBy { it.first }
                        (from..to).map { d -> Bucket(d, byDay[d]?.sumOf { it.third } ?: 0L) }
                    }
                    Period.YEAR -> {
                        val byMonth = rows.groupBy { LocalDate.ofEpochDay(it.first).monthValue }
                        (1..12).map { mo -> Bucket(mo.toLong(), byMonth[mo]?.sumOf { it.third } ?: 0L) }
                    }
                }
                val elapsedDays = (minOf(to, TimeUtils.today()) - from + 1).coerceAtLeast(1)
                StatsUi(p, from, to, total, total / elapsedDays, buckets, sumByApp(rows, names))
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StatsUi())
}

// ---------- History ----------

data class HistoryDay(val day: Long, val realMs: Long, val demoMin: Int?)
data class HistoryUi(
    val totalMs: Long = 0,
    val days: List<HistoryDay> = emptyList(),
    val firstDay: Long? = null,
    val avgMs: Long = 0
)
data class DayDetail(val name: String, val realMs: Long, val demoMin: Int)

@OptIn(ExperimentalCoroutinesApi::class)
class HistoryViewModel(private val c: AppContainer) : ViewModel() {
    val expanded = MutableStateFlow<Long?>(null)
    fun toggle(day: Long) { expanded.value = if (expanded.value == day) null else day }

    val ui: StateFlow<HistoryUi?> = combine(
        c.actualUsageRepository.observeAllDayTotals(),
        c.dailySnapshotRepository.all
    ) { totals, snaps ->
        val demoBy = snaps.filter { it.demoProfileId != null }.associate { it.dateEpochDay to it.demoTotalMinutes }
        val days = totals.map { HistoryDay(it.dateEpochDay, it.totalMs, demoBy[it.dateEpochDay]) }
        val total = totals.sumOf { it.totalMs }
        HistoryUi(total, days, totals.minOfOrNull { it.dateEpochDay }, if (days.isEmpty()) 0 else total / days.size)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val details: StateFlow<List<DayDetail>> = expanded.flatMapLatest { day ->
        if (day == null) {
            kotlinx.coroutines.flow.flowOf(emptyList())
        } else {
            combine(
                c.appInfoRepository.apps,
                c.actualUsageRepository.observeRange(day, day),
                c.demoAllocationRepository.observeDay(day)
            ) { apps, real, demo ->
                val names = apps.associate { it.packageName to it.appName }
                val realBy = real.associate { it.packageName to it.durationMs }
                val demoBy = demo.associate { it.packageName to it.allocatedMinutes }
                (realBy.keys + demoBy.keys).map { DayDetail(names[it] ?: it, realBy[it] ?: 0L, demoBy[it] ?: 0) }
                    .sortedByDescending { it.realMs }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

// ---------- Settings ----------

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    private val prefs = c.preferencesRepository
    val language = prefs.language
    val theme = prefs.theme
    val biometric = prefs.biometricEnabled
    val hasPin = prefs.hasPin
    val secret = SecretSearch(prefs, viewModelScope)
    val query = MutableStateFlow("")
    val message = MutableStateFlow<Msg?>(null)

    fun onQuery(q: String) { query.value = q; secret.onQuery(q) }
    fun setLanguage(l: String) = viewModelScope.launch { prefs.setLanguage(l) }
    fun setTheme(t: String) = viewModelScope.launch { prefs.setTheme(t) }
    fun setBiometric(on: Boolean) = viewModelScope.launch { prefs.setBiometricEnabled(on) }
    fun savePin(pin: String) = viewModelScope.launch { prefs.setPin(pin) }
    fun consumeMessage() { message.value = null }

    private fun io(block: suspend () -> Msg) = viewModelScope.launch {
        message.value = try {
            withContext(Dispatchers.IO) { block() }
        } catch (e: Exception) {
            Msg(R.string.action_failed)
        }
    }

    fun exportCsv(resolver: ContentResolver, uri: Uri) = io {
        resolver.openOutputStream(uri, "wt")!!.use { c.backupManager.exportCsv(it) }
        Msg(R.string.export_done)
    }

    fun exportBackup(resolver: ContentResolver, uri: Uri) = io {
        resolver.openOutputStream(uri, "wt")!!.use { c.backupManager.exportJson(it) }
        Msg(R.string.export_done)
    }

    fun restore(resolver: ContentResolver, uri: Uri) = io {
        val count = resolver.openInputStream(uri)!!.use { c.backupManager.importJson(it) }
        c.demoProfileRepository.ensureDefault()
        Msg(R.string.restore_done, count)
    }
}

// ---------- Secret configuration ----------

data class SecretPreview(val limitMin: Int = 0, val todayTotalMin: Int = 0, val apps: List<AppValue> = emptyList())

class SecretViewModel(private val c: AppContainer) : ViewModel() {
    val message = MutableStateFlow<Msg?>(null)
    fun consumeMessage() { message.value = null }

    val preview: StateFlow<SecretPreview> = combine(
        c.demoProfileRepository.activeProfile,
        c.demoAllocationRepository.observeDay(TimeUtils.today()),
        c.appInfoRepository.apps
    ) { profile, alloc, apps ->
        val names = apps.associate { it.packageName to it.appName }
        SecretPreview(profile?.totalMinutes ?: 0, alloc.sumOf { it.allocatedMinutes }, sumByApp(demoRows(alloc), names).take(8))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SecretPreview())

    private suspend fun regenerate(): Msg? = when (c.demoAllocationRepository.generateForDay(TimeUtils.today())) {
        is DemoResult.Generated -> null
        DemoResult.NoApps -> Msg(R.string.secret_no_apps)
        DemoResult.NoProfile -> Msg(R.string.action_failed)
    }

    fun save(hoursText: String, minutesText: String) = viewModelScope.launch {
        val h = if (hoursText.isBlank()) 0 else hoursText.trim().toIntOrNull()
        val m = if (minutesText.isBlank()) 0 else minutesText.trim().toIntOrNull()
        if (h == null || m == null) { message.value = Msg(R.string.secret_invalid); return@launch }
        val result = c.demoProfileRepository.saveConfiguration(h, m)
        message.value = if (result.isFailure) Msg(R.string.secret_invalid)
        else regenerate() ?: Msg(R.string.secret_saved)
    }

    fun recalculate() = viewModelScope.launch {
        message.value = regenerate() ?: Msg(R.string.secret_recalc_done)
    }

    fun reset() = viewModelScope.launch {
        c.demoProfileRepository.resetToDefault()
        message.value = regenerate() ?: Msg(R.string.secret_reset_done)
    }

    fun changeCode(newCode: String) = viewModelScope.launch {
        if (newCode.trim().length < 6) {
            message.value = Msg(R.string.secret_code_short)
        } else {
            withContext(Dispatchers.Default) { c.preferencesRepository.changeSecretCode(newCode.trim()) }
            message.value = Msg(R.string.secret_code_saved)
        }
    }
}
