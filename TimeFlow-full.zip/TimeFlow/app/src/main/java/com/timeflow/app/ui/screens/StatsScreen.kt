package com.timeflow.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.timeflow.app.AppContainer
import com.timeflow.app.R
import com.timeflow.app.ui.BarChart
import com.timeflow.app.ui.DemoBadge
import com.timeflow.app.ui.EmptyState
import com.timeflow.app.ui.Period
import com.timeflow.app.ui.ScreenTitle
import com.timeflow.app.ui.SoftCard
import com.timeflow.app.ui.StatMode
import com.timeflow.app.ui.StatsViewModel
import com.timeflow.app.ui.UsageRow
import com.timeflow.app.ui.rememberFmt

@Composable
fun StatsScreen(container: AppContainer) {
    val vm = containerViewModel(container) { StatsViewModel(it) }
    val ui by vm.ui.collectAsState()
    val mode by vm.mode.collectAsState()
    val offset by vm.offset.collectAsState()
    val fmt = rememberFmt()

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { ScreenTitle(stringResource(R.string.nav_stats)) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Period.DAY to R.string.period_day,
                    Period.WEEK to R.string.period_week,
                    Period.MONTH to R.string.period_month,
                    Period.YEAR to R.string.period_year
                ).forEach { (p, label) ->
                    FilterChip(selected = ui.period == p, onClick = { vm.setPeriod(p) }, label = { Text(stringResource(label)) })
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = mode == StatMode.REAL, onClick = { vm.setMode(StatMode.REAL) },
                    label = { Text(stringResource(R.string.mode_real)) })
                FilterChip(selected = mode == StatMode.DEMO, onClick = { vm.setMode(StatMode.DEMO) },
                    label = { Text(stringResource(R.string.mode_demo)) })
                if (mode == StatMode.DEMO) DemoBadge()
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = vm::previous) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = stringResource(R.string.previous))
                }
                Text(
                    when (ui.period) {
                        Period.DAY -> fmt.dateLabel(ui.rangeStart)
                        Period.WEEK -> fmt.dateLabel(ui.rangeStart) + " – " + fmt.dateLabel(ui.rangeEnd)
                        Period.MONTH -> fmt.monthYear(ui.rangeStart)
                        Period.YEAR -> fmt.year(ui.rangeStart)
                    },
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleMedium
                )
                IconButton(onClick = vm::next, enabled = offset < 0) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = stringResource(R.string.next))
                }
            }
        }
        if (ui.totalMs <= 0L) {
            item { EmptyState(stringResource(R.string.stats_empty)) }
        } else {
            item {
                SoftCard {
                    Text(stringResource(R.string.stats_total), style = MaterialTheme.typography.labelMedium)
                    Text(
                        fmt.duration(ui.totalMs),
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (ui.period != Period.DAY) {
                        Text(
                            stringResource(R.string.stats_daily_avg) + ": " + fmt.duration(ui.avgMs),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (ui.buckets.isNotEmpty()) {
                item {
                    SoftCard {
                        val n = ui.buckets.size
                        BarChart(
                            values = ui.buckets.map { it.ms },
                            labels = ui.buckets.mapIndexed { i, b ->
                                when (ui.period) {
                                    Period.WEEK -> fmt.weekdayShort(b.key)
                                    Period.MONTH ->
                                        if (i % 5 == 0 || i == n - 1) fmt.num(java.time.LocalDate.ofEpochDay(b.key).dayOfMonth) else ""
                                    else -> fmt.num(b.key)
                                }
                            }
                        )
                    }
                }
            }
            item {
                SoftCard {
                    Text(stringResource(R.string.stats_apps), style = MaterialTheme.typography.titleMedium)
                    val max = ui.apps.firstOrNull()?.ms ?: 0L
                    ui.apps.forEach { UsageRow(it.pkg, it.name, it.ms, max, fmt.duration(it.ms)) }
                }
            }
        }
    }
}
