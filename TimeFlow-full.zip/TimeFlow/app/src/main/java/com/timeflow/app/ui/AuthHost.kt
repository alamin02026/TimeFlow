package com.timeflow.app.ui

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.timeflow.app.R
import com.timeflow.app.data.repo.PreferencesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PendingAuth(val onSuccess: () -> Unit)

fun canUseBiometric(activity: FragmentActivity): Boolean =
    BiometricManager.from(activity)
        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

private fun launchBiometric(activity: FragmentActivity, title: String, cancel: String, onSuccess: () -> Unit) {
    val prompt = BiometricPrompt(
        activity,
        ContextCompat.getMainExecutor(activity),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onSuccess()
        }
    )
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle(title)
        .setNegativeButtonText(cancel)
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        .build()
    prompt.authenticate(info)
}

/** Asks for PIN (or biometric) before running the pending action. Creates a PIN first if none exists. */
@Composable
fun AuthHost(
    activity: FragmentActivity,
    prefs: PreferencesRepository,
    pending: PendingAuth?,
    onFinished: () -> Unit
) {
    if (pending == null) return
    val hasPin by prefs.hasPin.collectAsState(initial = null)
    val bioEnabled by prefs.biometricEnabled.collectAsState(initial = false)
    val scope = rememberCoroutineScope()
    val title = stringResource(R.string.auth_title)
    val cancel = stringResource(R.string.cancel)

    fun success() {
        val action = pending.onSuccess
        onFinished()
        action()
    }

    when (hasPin) {
        null -> Unit
        false -> PinSetupDialog(
            onDismiss = onFinished,
            onSave = { pin -> scope.launch { prefs.setPin(pin); success() } }
        )
        true -> {
            val bioAvailable = bioEnabled && canUseBiometric(activity)
            LaunchedEffect(pending) {
                if (bioAvailable) launchBiometric(activity, title, cancel) { success() }
            }
            PinVerifyDialog(
                showBiometric = bioAvailable,
                onBiometric = { launchBiometric(activity, title, cancel) { success() } },
                onDismiss = onFinished,
                verify = { pin -> withContext(Dispatchers.Default) { prefs.verifyPin(pin) } },
                onVerified = { success() }
            )
        }
    }
}

@Composable
fun PinVerifyDialog(
    showBiometric: Boolean,
    onBiometric: () -> Unit,
    onDismiss: () -> Unit,
    verify: suspend (String) -> Boolean,
    onVerified: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.auth_title)) },
        text = {
            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it.filter(Char::isDigit).take(8); wrong = false },
                label = { Text(stringResource(R.string.auth_enter_pin)) },
                singleLine = true,
                isError = wrong,
                supportingText = { if (wrong) Text(stringResource(R.string.auth_wrong)) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
            )
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch { if (verify(pin)) onVerified() else wrong = true }
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = {
            Row2(showBiometric, onBiometric, onDismiss)
        }
    )
}

@Composable
private fun Row2(showBiometric: Boolean, onBiometric: () -> Unit, onDismiss: () -> Unit) {
    androidx.compose.foundation.layout.Row {
        if (showBiometric) TextButton(onClick = onBiometric) { Text(stringResource(R.string.auth_use_biometric)) }
        TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
    }
}

@Composable
fun PinSetupDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<Int?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.auth_create_pin)) },
        text = {
            androidx.compose.foundation.layout.Column(
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter(Char::isDigit).take(8); error = null },
                    label = { Text(stringResource(R.string.auth_enter_pin)) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                OutlinedTextField(
                    value = confirm,
                    onValueChange = { confirm = it.filter(Char::isDigit).take(8); error = null },
                    label = { Text(stringResource(R.string.auth_confirm_pin)) },
                    singleLine = true,
                    isError = error != null,
                    supportingText = { error?.let { id -> Text(stringResource(id), color = MaterialTheme.colorScheme.error) } },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    pin.length !in 4..8 -> error = R.string.auth_pin_short
                    pin != confirm -> error = R.string.auth_mismatch
                    else -> onSave(pin)
                }
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

