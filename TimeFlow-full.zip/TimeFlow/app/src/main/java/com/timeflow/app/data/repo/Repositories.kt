package com.timeflow.app.data.repo

import androidx.room.withTransaction
import com.timeflow.app.data.db.ActualUsageDao
import com.timeflow.app.data.db.ActualUsageEntity
import com.timeflow.app.data.db.AppDatabase
import com.timeflow.app.data.db.AppInfoDao
import com.timeflow.app.data.db.AppInfoEntity
import com.timeflow.app.data.db.DailySnapshotDao
import com.timeflow.app.data.db.DailySnapshotEntity
import com.timeflow.app.data.db.DayTotal
import com.timeflow.app.data.db.DemoAllocationDao
import com.timeflow.app.data.db.DemoAllocationEntity
import com.timeflow.app.data.db.DemoProfileDao
import com.timeflow.app.data.db.DemoProfileEntity
import com.timeflow.app.domain.AllocationEngine
import kotlinx.coroutines.flow.Flow

class AppInfoRepository(private val dao: AppInfoDao) {
    val apps: Flow<List<AppInfoEntity>> = dao.observeAll()
    suspend fun saveAll(items: List<AppInfoEntity>) = dao.upsertAll(items)
    suspend fun getAll(): List<AppInfoEntity> = dao.getAll()
}

class ActualUsageRepository(private val dao: ActualUsageDao) {
    suspend fun saveAll(items: List<ActualUsageEntity>) = dao.upsertAll(items)
    suspend fun forDay(day: Long): List<ActualUsageEntity> = dao.forDay(day)
    fun observeRange(from: Long, to: Long): Flow<List<ActualUsageEntity>> = dao.observeRange(from, to)
    fun observeDayTotals(from: Long, to: Long): Flow<List<DayTotal>> = dao.observeDayTotals(from, to)
    suspend fun earliestDay(): Long? = dao.earliestDay()
    fun observeAllDayTotals(): Flow<List<DayTotal>> = dao.observeAllDayTotals()
}

class DemoProfileRepository(
    private val db: AppDatabase,
    private val dao: DemoProfileDao
) {
    val activeProfile: Flow<DemoProfileEntity?> = dao.observeActive()
    val allProfiles: Flow<List<DemoProfileEntity>> = dao.observeAll()

    /** Creates the initial 2h 52m weighted profile the first time the app runs. */
    suspend fun ensureDefault() {
        if (dao.count() == 0) createActive(DEFAULT_MINUTES, "Default")
    }

    /** New profile becomes active. Older profiles and past reports are kept. */
    suspend fun saveConfiguration(hours: Int, minutes: Int): Result<DemoProfileEntity> {
        if (hours < 0 || minutes !in 0..59) {
            return Result.failure(IllegalArgumentException("Invalid time"))
        }
        val total = hours * 60 + minutes
        if (total <= 0 || total > MAX_MINUTES) {
            return Result.failure(IllegalArgumentException("Time must be between 1 minute and 24 hours"))
        }
        return Result.success(createActive(total, "Custom"))
    }

    suspend fun resetToDefault(): DemoProfileEntity = createActive(DEFAULT_MINUTES, "Default")

    private suspend fun createActive(totalMinutes: Int, name: String): DemoProfileEntity =
        db.withTransaction {
            dao.deactivateAll()
            val draft = DemoProfileEntity(
                name = name,
                totalMinutes = totalMinutes,
                isActive = true,
                createdAt = System.currentTimeMillis()
            )
            draft.copy(id = dao.insert(draft))
        }

    companion object {
        const val DEFAULT_MINUTES = 2 * 60 + 52
        const val MAX_MINUTES = 24 * 60
    }
}

sealed interface DemoResult {
    data class Generated(val totalMinutes: Int, val appCount: Int) : DemoResult
    data object NoApps : DemoResult
    data object NoProfile : DemoResult
}

class DemoAllocationRepository(
    private val db: AppDatabase,
    private val usageDao: ActualUsageDao,
    private val appInfoDao: AppInfoDao,
    private val profileDao: DemoProfileDao,
    private val allocationDao: DemoAllocationDao,
    private val snapshotDao: DailySnapshotDao
) {
    fun observeDay(day: Long): Flow<List<DemoAllocationEntity>> = allocationDao.observeDay(day)
    fun observeRange(from: Long, to: Long): Flow<List<DemoAllocationEntity>> =
        allocationDao.observeRange(from, to)
    suspend fun hasReport(day: Long): Boolean = allocationDao.forDay(day).isNotEmpty()

    /**
     * Builds (or rebuilds) the Demo report for one day from that day's real usage.
     * Only the given day is replaced; other days and real usage rows are untouched.
     * If the day has no real usage, user apps share the limit equally.
     */
    suspend fun generateForDay(day: Long): DemoResult = db.withTransaction {
        val profile = profileDao.getActive() ?: return@withTransaction DemoResult.NoProfile
        val usage = usageDao.forDay(day).filter { it.durationMs > 0 }
        val weights: Map<String, Long> =
            if (usage.isNotEmpty()) {
                usage.associate { it.packageName to it.durationMs }
            } else {
                appInfoDao.getAll().filter { !it.isSystemApp }.associate { it.packageName to 0L }
            }
        if (weights.isEmpty()) return@withTransaction DemoResult.NoApps

        val minutes = AllocationEngine.allocate(profile.totalMinutes, weights)
        allocationDao.deleteForDay(day)
        allocationDao.insertAll(
            minutes.map { (pkg, m) ->
                DemoAllocationEntity(
                    profileId = profile.id,
                    dateEpochDay = day,
                    packageName = pkg,
                    weightMs = weights.getValue(pkg),
                    allocatedMinutes = m
                )
            }
        )
        snapshotDao.upsert(
            DailySnapshotEntity(
                dateEpochDay = day,
                totalActualMs = usage.sumOf { it.durationMs },
                demoProfileId = profile.id,
                demoTotalMinutes = profile.totalMinutes,
                createdAt = System.currentTimeMillis()
            )
        )
        DemoResult.Generated(profile.totalMinutes, minutes.size)
    }
}

class DailySnapshotRepository(private val dao: DailySnapshotDao) {
    val all: Flow<List<DailySnapshotEntity>> = dao.observeAll()
    fun observeRange(from: Long, to: Long): Flow<List<DailySnapshotEntity>> = dao.observeRange(from, to)
    suspend fun get(day: Long): DailySnapshotEntity? = dao.get(day)
}
