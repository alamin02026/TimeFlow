package com.timeflow.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.timeflow.app.AppContainer
import com.timeflow.app.R
import com.timeflow.app.ui.BarChart
import com.timeflow.app.ui.DemoBadge
import com.timeflow.app.ui.HomeViewModel
import com.timeflow.app.ui.PermissionCard
import com.timeflow.app.ui.ScreenTitle
import com.timeflow.app.ui.SoftCard
import com.timeflow.app.ui.UsageRow
import com.timeflow.app.ui.rememberFmt

@Composable
fun HomeScreen(
    container: AppContainer,
    granted: Boolean,
    syncing: Boolean,
    resumeTick: Int,
    onGrant: () -> Unit,
    onRefresh: () -> Unit
) {
    val vm = containerViewModel(container) { HomeViewModel(it) }
    LaunchedEffect(resumeTick) { vm.refreshDay() }
    val ui by vm.ui.collectAsState()
    val fmt = rememberFmt()

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenTitle(stringResource(R.string.app_name)) {
                IconButton(onClick = onRefresh, enabled = !syncing) {
                    if (syncing) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Filled.Refresh, contentDescription = stringResource(R.string.refresh))
                }
            }
        }
        if (!granted) item { PermissionCard(onGrant) }

        item {
            SoftCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.home_demo_report), style = MaterialTheme.typography.titleMedium)
                    DemoBadge()
                }
                Text(
                    fmt.minutes(ui.demoTotalMin),
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    stringResource(R.string.demo_limit_label) + ": " + fmt.minutes(ui.limitMin),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (ui.demoTop.isEmpty()) {
                    Text(
                        stringResource(if (granted) R.string.home_demo_empty else R.string.home_empty_no_access),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(stringResource(R.string.home_top_apps), style = MaterialTheme.typography.labelMedium)
                    val max = ui.demoTop.first().ms
                    ui.demoTop.forEach { UsageRow(it.pkg, it.name, it.ms, max, fmt.duration(it.ms)) }
                }
            }
        }

        item {
            SoftCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.home_last7), style = MaterialTheme.typography.titleMedium)
                    DemoBadge()
                }
                BarChart(
                    values = ui.last7Demo.map { it.second },
                    labels = ui.last7Demo.map { fmt.weekdayShort(it.first) }
                )
            }
        }
    }
}
