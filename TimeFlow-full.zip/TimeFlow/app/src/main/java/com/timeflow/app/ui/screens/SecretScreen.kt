package com.timeflow.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.timeflow.app.AppContainer
import com.timeflow.app.R
import com.timeflow.app.ui.DemoBadge
import com.timeflow.app.ui.SecretViewModel
import com.timeflow.app.ui.SoftCard
import com.timeflow.app.ui.UsageRow
import com.timeflow.app.ui.rememberFmt

/** Shown only after Secret Code + PIN / biometric authentication succeeded. */
@Composable
fun SecretScreen(container: AppContainer, onBack: () -> Unit) {
    val vm = containerViewModel(container) { SecretViewModel(it) }
    val preview by vm.preview.collectAsState()
    val message by vm.message.collectAsState()
    val host = remember { SnackbarHostState() }
    val fmt = rememberFmt()
    var hours by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("") }
    var newCode by remember { mutableStateOf("") }
    var confirmReset by remember { mutableStateOf(false) }

    MessageEffect(message, host) { vm.consumeMessage() }
    LaunchedEffect(preview.limitMin) {
        if (preview.limitMin > 0) {
            hours = (preview.limitMin / 60).toString()
            minutes = (preview.limitMin % 60).toString()
        }
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                    Text(stringResource(R.string.secret_title), style = MaterialTheme.typography.headlineMedium)
                }
            }
            // Hidden Real Usage Card (Only accessible via Secret Code)
            item {
                SoftCard {
                    Text(stringResource(R.string.secret_real_section), style = MaterialTheme.typography.titleMedium)
                    Text(
                        fmt.duration(preview.realTotalMs),
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (preview.realApps.isEmpty()) {
                        Text(stringResource(R.string.home_empty), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        val maxReal = preview.realApps.first().ms
                        preview.realApps.forEach { UsageRow(it.pkg, it.name, it.ms, maxReal, fmt.duration(it.ms)) }
                    }
                }
            }
            // Demo Configuration Card
            item {
                SoftCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.secret_current), style = MaterialTheme.typography.titleMedium)
                        DemoBadge()
                    }
                    Text(
                        fmt.minutes(preview.limitMin),
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    AssistChip(onClick = {}, label = { Text(stringResource(R.string.secret_method)) })
                    Text(
                        stringResource(R.string.secret_method_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = hours,
                            onValueChange = { hours = it.filter(Char::isDigit).take(2) },
                            label = { Text(stringResource(R.string.secret_hours)) },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = minutes,
                            onValueChange = { minutes = it.filter(Char::isDigit).take(2) },
                            label = { Text(stringResource(R.string.secret_minutes)) },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                    Button(onClick = { vm.save(hours, minutes) }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.secret_save))
                    }
                    FilledTonalButton(onClick = vm::recalculate, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.secret_recalc))
                    }
                    OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.secret_reset))
                    }
                }
            }
            // Demo Preview Card
            item {
                SoftCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.secret_preview), style = MaterialTheme.typography.titleMedium)
                        DemoBadge()
                    }
                    if (preview.apps.isEmpty()) {
                        Text(stringResource(R.string.home_demo_empty), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text(fmt.minutes(preview.todayTotalMin), style = MaterialTheme.typography.titleLarge)
                        val max = preview.apps.first().ms
                        preview.apps.forEach { UsageRow(it.pkg, it.name, it.ms, max, fmt.duration(it.ms)) }
                    }
                }
            }
            // Change Secret Code Card
            item {
                SoftCard {
                    Text(stringResource(R.string.secret_change_code), style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = newCode,
                        onValueChange = { newCode = it.take(32) },
                        label = { Text(stringResource(R.string.secret_new_code)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = PasswordVisualTransformation()
                    )
                    OutlinedButton(onClick = { vm.changeCode(newCode); newCode = "" }) {
                        Text(stringResource(R.string.secret_change_code))
                    }
                }
            }
        }
        SnackbarHost(host, Modifier.align(Alignment.BottomCenter))
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text(stringResource(R.string.secret_reset)) },
            text = { Text(stringResource(R.string.secret_reset_confirm)) },
            confirmButton = {
                TextButton(onClick = { confirmReset = false; vm.reset() }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
